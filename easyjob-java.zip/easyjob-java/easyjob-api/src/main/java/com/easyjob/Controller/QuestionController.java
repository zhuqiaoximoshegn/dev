package com.easyjob.Controller;

import com.easyjob.annotation.GlobalInterceptor;
import com.easyjob.annotation.VerifyParam;
import com.easyjob.entity.dto.AppUserLoginDto;
import com.easyjob.entity.enums.CollectTypeEnum;
import com.easyjob.entity.enums.PostStatusEnum;
import com.easyjob.entity.po.QuestionInfo;
import com.easyjob.entity.query.QuestionInfoQuery;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.QuestionInfoService;

import javax.annotation.Resource;

@RestController
@RequestMapping("/question")
public class QuestionController extends ABaseController {

    @Resource
    private QuestionInfoService questionInfoService;

    @Resource
    private AppUserCollectService appUserCollectService;

    @RequestMapping("/loadQuestion")
    @GlobalInterceptor
    public ResponseVO loadQuestion(Integer pageNo, Integer categoryId){
        QuestionInfoQuery query=new QuestionInfoQuery();
        query.setPageNo(pageNo);
        query.setCategoryId(categoryId);
        query.setOrderBy("question_id desc");

        if(query.getCategoryId()!=null && query.getCategoryId()==0){
            query.setCategoryId(null);
        }
        query.setQueryTextContent(false);
        query.setStatus(PostStatusEnum.POST.getStatus());
        return getSuccessResponseVO(questionInfoService.findListByPage(query));
    }

    @RequestMapping("/getQuestionDetailNext")
    @GlobalInterceptor
    public ResponseVO getQuestionDetailNext(@RequestHeader(value="token", required=false) String token,
                                            @VerifyParam(required = true) Integer currentId, Integer nextType){
        QuestionInfoQuery query=new QuestionInfoQuery();
        query.setStatus(PostStatusEnum.POST.getStatus());

        QuestionInfo questionInfo=questionInfoService.showDetailNext(query,nextType,currentId,true);

        AppUserLoginDto userLoginDto= getAppUserLogInfoFromToken(token);
        if(null!=userLoginDto){
            AppUserCollect appUserCollect=appUserCollectService.getAppUserCollectByUserIdAndObjectIdAndCollectType(userLoginDto.getUserId(),questionInfo.getQuestionId().toString(), CollectTypeEnum.QUESTION.getType());

            if(appUserCollect!=null){
                questionInfo.setHaveCollect(true);
            }
        }

        questionInfo.setQuestion(resetContentImg(questionInfo.getQuestion()));
        questionInfo.setAnswerAnalysis(resetContentImg(questionInfo.getAnswerAnalysis()));
        return getSuccessResponseVO(questionInfoService.findListByPage(query));
    }

}
