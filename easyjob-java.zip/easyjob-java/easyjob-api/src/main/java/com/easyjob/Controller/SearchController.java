package com.easyjob.Controller;

import com.easyjob.annotation.GlobalInterceptor;
import com.easyjob.annotation.VerifyParam;
import com.easyjob.entity.enums.PostStatusEnum;
import com.easyjob.entity.enums.RequestFrequencyTypeEnum;
import com.easyjob.entity.enums.ResponseCodeEnum;
import com.easyjob.entity.enums.SearchTypeEnum;
import com.easyjob.entity.po.*;
import com.easyjob.entity.query.*;
import com.easyjob.entity.vo.PaginationResultVO;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.exception.BusinessException;
import com.easyjob.service.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/search")
public class SearchController extends ABaseController{

    @Resource
    private QuestionInfoService questionInfoService;

    @Resource
    private ExamQuestionService examQuestionService;

    @Resource
    private ShareInfoService shareInfoService;

    @RequestMapping("/search")
    @GlobalInterceptor(frequencyType = RequestFrequencyTypeEnum.MINUTE,requestFrequencyThreshold = 20)
    public ResponseVO search(@VerifyParam(required = true,min=3) String keyword,
                             @VerifyParam(required = true) Integer type,
                             Integer pageNo){
        SearchTypeEnum searchTypeEnum= SearchTypeEnum.getByType(type);
        if(null==searchTypeEnum){
            throw new BusinessException(ResponseCodeEnum.CODE_600);
        }

        switch (searchTypeEnum){
            case QUESTION:
                QuestionInfoQuery query=new QuestionInfoQuery();
                query.setPageNo(pageNo);
                query.setTitleFuzzy(keyword);
                query.setOrderBy("question_id desc");
                query.setQueryTextContent(false);
                query.setStatus(PostStatusEnum.POST.getStatus());
                PaginationResultVO<QuestionInfo> questionInfoVO=questionInfoService.findListByPage(query);

                for(QuestionInfo item:questionInfoVO.getList()){
                    item.setQuestion(resetContentImg(item.getQuestion()));
                    item.setAnswerAnalysis(resetContentImg(item.getAnswerAnalysis()));
                }
                return getSuccessResponseVO(questionInfoVO);
            case EXAM_QUESTION:
                ExamQuestionQuery examQuestionQuery=new ExamQuestionQuery();
                examQuestionQuery.setPageNo(pageNo);
                examQuestionQuery.setTitleFuzzy(keyword);
                examQuestionQuery.setOrderBy("question_id desc");  //?
                examQuestionQuery.setStatus(PostStatusEnum.POST.getStatus());
                examQuestionQuery.setQueryAnswer(true);
                examQuestionQuery.setQueryQuestionItem(true);

                PaginationResultVO<ExamQuestion> examQuestionVO=examQuestionService.findListByPage(examQuestionQuery);
                for(ExamQuestion item:examQuestionVO.getList()){
                    item.setQuestion(resetContentImg(item.getQuestion()));
                    item.setAnswerAnalysis(resetContentImg(item.getAnswerAnalysis()));
                }
                return getSuccessResponseVO(examQuestionVO);
            case SHARE:
                ShareInfoQuery shareInfoQuery=new ShareInfoQuery();
                shareInfoQuery.setPageNo(pageNo);
                shareInfoQuery.setTitleFuzzy(keyword);
                shareInfoQuery.setOrderBy("share_id desc");
                shareInfoQuery.setStatus(PostStatusEnum.POST.getStatus());
                shareInfoQuery.setQueryTextContent(false);

                PaginationResultVO<ShareInfo> shareInfoVO=shareInfoService.findListByPage(shareInfoQuery);
                for(ShareInfo item:shareInfoVO.getList()){
                    item.setContent(resetContentImg(item.getContent()));
                }
                return getSuccessResponseVO(shareInfoVO);
            default:
                throw new BusinessException(ResponseCodeEnum.CODE_600);
        }
    }

}
