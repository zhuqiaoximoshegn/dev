package com.easyjob.Controller;

import com.easyjob.entity.config.AppConfig;
import com.easyjob.entity.constants.Constants;
import com.easyjob.entity.dto.AppUserLoginDto;
import com.easyjob.entity.dto.SessionUserAdminDto;
import com.easyjob.entity.enums.ResponseCodeEnum;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.exception.BusinessException;
import com.easyjob.utils.JWTUtil;
import com.easyjob.utils.StringTools;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;


public class ABaseController {

    @Resource
    private AppConfig appConfig;

    @Resource
    private JWTUtil<AppUserLoginDto> jwtUtil;

    protected static final String STATUC_SUCCESS = "success";

    protected static final String STATUC_ERROR = "error";

    protected <T> ResponseVO getSuccessResponseVO(T t) {
        ResponseVO<T> responseVO = new ResponseVO<>();
        responseVO.setStatus(STATUC_SUCCESS);
        responseVO.setCode(ResponseCodeEnum.CODE_200.getCode());
        responseVO.setInfo(ResponseCodeEnum.CODE_200.getMsg());
        responseVO.setData(t);
        return responseVO;
    }

    protected <T> ResponseVO getBusinessErrorResponseVO(BusinessException e, T t) {
        ResponseVO vo = new ResponseVO();
        vo.setStatus(STATUC_ERROR);
        if (e.getCode() == null) {
            vo.setCode(ResponseCodeEnum.CODE_600.getCode());
        } else {
            vo.setCode(e.getCode());
        }
        vo.setInfo(e.getMessage());
        vo.setData(t);
        return vo;
    }

    protected <T> ResponseVO getServerErrorResponseVO(T t) {
        ResponseVO vo = new ResponseVO();
        vo.setStatus(STATUC_ERROR);
        vo.setCode(ResponseCodeEnum.CODE_500.getCode());
        vo.setInfo(ResponseCodeEnum.CODE_500.getMsg());
        vo.setData(t);
        return vo;
    }

    protected AppUserLoginDto getAppUserLogInfoFromToken(String token) {
        AppUserLoginDto loginDto=jwtUtil.getTokenData(Constants.JWT_KEY_LOGIN_TOKEN,token,AppUserLoginDto.class);
        return loginDto;
    }

    protected String getIpAddr(HttpServletRequest request){
        String ip=request.getHeader("x-forwarded-for");
        if(ip!=null&&ip.length()!=0&&!"unknown".equalsIgnoreCase(ip)){
            //多次反向代理后多个ip,第一个ip是真实ip
            if(ip.indexOf(",")!=-1){
                ip=ip.split(",")[0];
            }
        }
        if(ip==null||ip.length()==0||"unknown".equalsIgnoreCase(ip)){
            ip=request.getHeader("Proxy-Client-IP");
        }
        if(ip==null||ip.length()==0||"unknown".equalsIgnoreCase(ip)){
            ip=request.getHeader("WL-Proxy-Client-IP");
        }
        if(ip==null||ip.length()==0||"unknown".equalsIgnoreCase(ip)){
            ip=request.getHeader("HTTP_CLIENT_IP");
        }
        if(ip==null||ip.length()==0||"unknown".equalsIgnoreCase(ip)){
            ip=request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if(ip==null||ip.length()==0||"unknown".equalsIgnoreCase(ip)){
            ip=request.getHeader("X-Real-IP");
        }
        if(ip==null||ip.length()==0||"unknown".equalsIgnoreCase(ip)){
            ip=request.getRemoteAddr();
        }
        return ip;
    }

    protected String resetContentImg(String content){
        if(StringTools.isEmpty(content)){
            return content;
        }
        content=content.replace(Constants.READ_IMAGE_PATH,appConfig.getAppDomain()+Constants.READ_IMAGE_PATH);
        return content;
    }
}
