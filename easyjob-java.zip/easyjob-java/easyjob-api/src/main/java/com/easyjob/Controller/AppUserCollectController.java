package com.easyjob.Controller;

import com.easyjob.annotation.GlobalInterceptor;
import com.easyjob.annotation.VerifyParam;
import com.easyjob.entity.dto.AppUserLoginDto;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppUserCollectService;

import javax.annotation.Resource;

@RestController
@RequestMapping("/appUserCollect")
public class AppUserCollectController extends ABaseController {

    @Resource
    private AppUserCollectService appUserCollectService;

    @RequestMapping("/addCollect")
    @GlobalInterceptor(checkLogin = true)
    public ResponseVO addCollect(@RequestHeader(value="token",required=false) String token,
                                 @VerifyParam(required = true) String objectId,
                                 @VerifyParam(required = true) Integer collectType){
        AppUserLoginDto loginDto= getAppUserLogInfoFromToken(token);
        appUserCollectService.saveCollect(loginDto.getUserId(),objectId,collectType);
        return getSuccessResponseVO(null);
    }

    @RequestMapping("/cancelCollect")
    @GlobalInterceptor(checkLogin = true)
    public ResponseVO cancelCollect(@RequestHeader(value="token",required=false) String token,
                                    @VerifyParam(required = true) String objectId,
                                    @VerifyParam(required = true) Integer collectType){
        AppUserLoginDto loginDto= getAppUserLogInfoFromToken(token);
        appUserCollectService.deleteAppUserCollectByUserIdAndObjectIdAndCollectType(loginDto.getUserId(),objectId,collectType);
        return getSuccessResponseVO(null);
    }
}
