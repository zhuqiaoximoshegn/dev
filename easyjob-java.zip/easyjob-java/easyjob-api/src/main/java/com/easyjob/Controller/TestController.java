package com.easyjob.Controller;

@RestController
public class TestController {
    @RequestMapping("/test")
    public String test() {
        return "项目Api构建成功了";
    }
}
