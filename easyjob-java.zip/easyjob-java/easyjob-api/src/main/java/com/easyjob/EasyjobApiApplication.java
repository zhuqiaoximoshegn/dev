package com.easyjob;

@SpringBootApplication(scanBasePackage={"com.easyjob"})
@MapperScan(basePackages = {"com.easyjob.mappers"})
@EnableTransactionManagement
@EnableScheduling
@EnableAsync
public class EasyjobApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(EasyjobAdminApplication.class,args);
    }
}
