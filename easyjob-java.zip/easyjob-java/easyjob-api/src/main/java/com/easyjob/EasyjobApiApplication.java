package com.easyjob;

@SpringBootApplication(scanBasePackage={"com.easyjob"})
@EnableTransactionManagement
@EnableScheduling
@EnableAsync
public class EasyjobApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(EasyjobAdminApplication.class,args);
    }
}
