package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppUserCollectQuery;
import com.easyjob.entity.po.AppUserCollect;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppUserCollectService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 用户收藏 Controller
 */
@RestController("appUserCollectController")
@RequestMapping("/appUserCollect")
public class AppUserCollectController extends ABaseController{

	@Resource
	private AppUserCollectService appUserCollectService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppUserCollectQuery query){
		return getSuccessResponseVO(appUserCollectService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppUserCollect bean) {
		appUserCollectService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppUserCollect> listBean) {
		appUserCollectService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppUserCollect> listBean) {
		appUserCollectService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据CollectId查询对象
	 */
	@RequestMapping("/getAppUserCollectByCollectId")
	public ResponseVO getAppUserCollectByCollectId(Integer collectId) {
		return getSuccessResponseVO(appUserCollectService.getAppUserCollectByCollectId(collectId));
	}

	/**
	 * 根据CollectId修改对象
	 */
	@RequestMapping("/updateAppUserCollectByCollectId")
	public ResponseVO updateAppUserCollectByCollectId(AppUserCollect bean,Integer collectId) {
		appUserCollectService.updateAppUserCollectByCollectId(bean,collectId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据CollectId删除
	 */
	@RequestMapping("/deleteAppUserCollectByCollectId")
	public ResponseVO deleteAppUserCollectByCollectId(Integer collectId) {
		appUserCollectService.deleteAppUserCollectByCollectId(collectId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据UserIdAndObjectIdAndCollectType查询对象
	 */
	@RequestMapping("/getAppUserCollectByUserIdAndObjectIdAndCollectType")
	public ResponseVO getAppUserCollectByUserIdAndObjectIdAndCollectType(String userId,String objectId,Integer collectType) {
		return getSuccessResponseVO(appUserCollectService.getAppUserCollectByUserIdAndObjectIdAndCollectType(userId,objectId,collectType));
	}

	/**
	 * 根据UserIdAndObjectIdAndCollectType修改对象
	 */
	@RequestMapping("/updateAppUserCollectByUserIdAndObjectIdAndCollectType")
	public ResponseVO updateAppUserCollectByUserIdAndObjectIdAndCollectType(AppUserCollect bean,String userId,String objectId,Integer collectType) {
		appUserCollectService.updateAppUserCollectByUserIdAndObjectIdAndCollectType(bean,userId,objectId,collectType);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据UserIdAndObjectIdAndCollectType删除
	 */
	@RequestMapping("/deleteAppUserCollectByUserIdAndObjectIdAndCollectType")
	public ResponseVO deleteAppUserCollectByUserIdAndObjectIdAndCollectType(String userId,String objectId,Integer collectType) {
		appUserCollectService.deleteAppUserCollectByUserIdAndObjectIdAndCollectType(userId,objectId,collectType);
		return getSuccessResponseVO(null);
	}


}