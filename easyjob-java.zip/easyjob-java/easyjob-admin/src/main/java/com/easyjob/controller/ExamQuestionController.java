package com.easyjob.controller;

import com.easyjob.annotation.GlobalInterceptor;
import com.easyjob.annotation.VerifyParam;
import com.easyjob.entity.dto.SessionUserAdminDto;
import com.easyjob.entity.enums.PermissionCodeEnum;
import com.easyjob.entity.po.ExamQuestion;
import com.easyjob.entity.query.ExamQuestionQuery;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.ExamQuestionService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

/**
 * 考试题目 Controller
 */
@RestController("examQuestionController")
@RequestMapping("/examQuestion")
public class ExamQuestionController extends ABaseController {

    @Resource
    private ExamQuestionService examQuestionService;

    /**
     * 根据条件分页查询
     */
    @RequestMapping("/loadDataList")
    @GlobalInterceptor(permissionCode = PermissionCodeEnum.EXAM_QUESTION_LIST)
    public ResponseVO loadDataList(ExamQuestionQuery query) {
        query.setOrderBy("question_id desc");
        query.setQueryAnswer(true);
        return getSuccessResponseVO(examQuestionService.findListByPage(query));
    }

    @RequestMapping("/saveExamQuestion")
    @GlobalInterceptor(permissionCode = PermissionCodeEnum.EXAM_QUESTION_LIST)
    public ResponseVO saveExamQuestion(HttpSession session, @VerifyParam(required = true) ExamQuestion examQuestion,
                                       String questionItemListJson) {
        SessionUserAdminDto userAdminDto = getUserAdminFromSession(session);
        examQuestion.setCreateUserId(String.valueOf(userAdminDto.getUserId()));
        examQuestion.setCreateUserName(userAdminDto.getUserName());
        return getSuccessResponseVO(examQuestionService.findListByPage(query));
    }
}