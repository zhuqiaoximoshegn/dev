package com.easyjob.annotation;

import com.easyjob.entity.enums.PermissionCodeEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//aop注解
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface GlobalInterceptor {
    boolean checkLogin() default true;

    boolean checkParams() default true;

    PermissionCodeEnum permissionCode() default PermissionCodeEnum.NO_PERMISSION;
}
