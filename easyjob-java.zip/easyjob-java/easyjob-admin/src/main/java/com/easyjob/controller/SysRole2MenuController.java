package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.SysRole2MenuQuery;
import com.easyjob.entity.po.SysRole2Menu;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.SysRole2MenuService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 系统角色表 Controller
 */
@RestController("sysRole2MenuController")
@RequestMapping("/sysRole2Menu")
public class SysRole2MenuController extends ABaseController{

	@Resource
	private SysRole2MenuService sysRole2MenuService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(SysRole2MenuQuery query){
		return getSuccessResponseVO(sysRole2MenuService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(SysRole2Menu bean) {
		sysRole2MenuService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<SysRole2Menu> listBean) {
		sysRole2MenuService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<SysRole2Menu> listBean) {
		sysRole2MenuService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据RoleIdAndMenuId查询对象
	 */
	@RequestMapping("/getSysRole2MenuByRoleIdAndMenuId")
	public ResponseVO getSysRole2MenuByRoleIdAndMenuId(Integer roleId,Integer menuId) {
		return getSuccessResponseVO(sysRole2MenuService.getSysRole2MenuByRoleIdAndMenuId(roleId,menuId));
	}

	/**
	 * 根据RoleIdAndMenuId修改对象
	 */
	@RequestMapping("/updateSysRole2MenuByRoleIdAndMenuId")
	public ResponseVO updateSysRole2MenuByRoleIdAndMenuId(SysRole2Menu bean,Integer roleId,Integer menuId) {
		sysRole2MenuService.updateSysRole2MenuByRoleIdAndMenuId(bean,roleId,menuId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据RoleIdAndMenuId删除
	 */
	@RequestMapping("/deleteSysRole2MenuByRoleIdAndMenuId")
	public ResponseVO deleteSysRole2MenuByRoleIdAndMenuId(Integer roleId,Integer menuId) {
		sysRole2MenuService.deleteSysRole2MenuByRoleIdAndMenuId(roleId,menuId);
		return getSuccessResponseVO(null);
	}
}