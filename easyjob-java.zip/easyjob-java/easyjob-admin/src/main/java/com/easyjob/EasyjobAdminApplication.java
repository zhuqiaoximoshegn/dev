package com.easyjob;

@SpringBootApplication(scanBasePackage={"com.easyjob"})
@EnableTransactionManagement
@EnableScheduling
@EnableAsync
@MapperScan(scanBasePackage={"com.easyjob.mappers"})
public class EasyjobAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(EasyjobAdminApplication.class,args);
    }
}
