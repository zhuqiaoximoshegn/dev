package com.easyjob.aspect;
//aop 切面类
import org.aspectj.lang.annotation.Aspect;
@Aspect
@Component("operationAspect")
public class OperationAspect {
    private Logger logger=LoggerFactory.getLogger(OperationAspect.class);

    @Before("@annotation(com.easyjob.annotation.GlobalInterceptor)")
    public void interceptorDo(JoinPoint point){
        logger.info(point.getArgs().toString());
    }

}
