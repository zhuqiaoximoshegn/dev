package com.easyjob.controller;

import com.easyjob.annotation.GlobalInterceptor;
import com.easyjob.entity.dto.CreateImageCode;
import com.easyjob.entity.enums.ResponseCodeEnum;
import com.easyjob.entity.enums.SysAccountStatusEnum;
import com.easyjob.entity.po.SysAccount;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.exception.BusinessException;
import com.easyjob.service.SysAccountService;
import com.easyjob.entity.constants.Constants;
import com.easyjob.utils.StringTools;

import javax.annotation.Resource;

@RestController
public class LoginController extends ABaseController{
    @Resource
    private SysAccountService sysAccountService;

    @RequestMapping("/checkCode")
    public void checkCode(HttpServletResponse response,HttpSession session){
        CreateImageCode vCode=new CreateImageCode(130,38,5,10);
        response.setHeader("Pragma","no-cache");
        response.setHeader("Cache-Control","no-cache");
        response.setDateHeader("Expires",0);
        response.setContentType("image/jpeg");

        String code=vCode.getCode();
        session.setAttribute(Constants.CHECK_CODE_KEY, code);
        vCode.write(response.getOutputStream());
    }

    @RequestMapping("/login")
    @GlobalInterceptor
    public ResponseVO login(HttpSession session,String phone,String password,String checkCode){

        if(StringTools.isEmpty(phone)||StringTools.isEmpty(password)||StringTools.isEmpty(checkCode)){
            throw new BusinessException(ResponseCodeEnum.CODE_600);
        }

        if(!checkCode.equalsIgnoreCase((String)session.getAttribute(Constants.CHECK_CODE_KEY))){
            throw new BusinessException("图片验证码错误");
        }

        sysAccountService.login(phone,password);
        return getSuccessResponseVO(null);
    }

}
