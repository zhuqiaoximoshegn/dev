package com.easyjob.entity.enums;

public enum AppUpdateTypeEnum {
    ALL(0,".apk","全更新"),WGT(1,".wgt","局部热更新");

    private Integer type;
    private String suffix;
    private String description;

    public Integer getType() {
        return type;
    }

    public String getSuffix() {
        return suffix;
    }

    public String getDescription() {
        return description;
    }

    AppUpdateTypeEnum(Integer type, String suffix, String description) {
        this.type = type;
        this.suffix = suffix;
        this.description = description;
    }

    public static AppUpdateTypeEnum getByType(Integer type){
        for(AppUpdateTypeEnum at:AppUpdateTypeEnum.values()){
            if(at.getType().equals(type)){
                return at;
            }
        }
        return null;
    }
}
