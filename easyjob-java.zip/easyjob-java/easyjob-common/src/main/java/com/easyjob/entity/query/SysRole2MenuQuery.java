package com.easyjob.entity.query;



/**
 * 系统角色表参数
 */
public class SysRole2MenuQuery extends BaseParam {


	/**
	 * 角色ID
	 */
	private Integer roleId;

	/**
	 * 菜单ID
	 */
	private Integer menuId;

	/**
	 * 0:半选 1:全选
	 */
	private Integer checkType;


	public void setRoleId(Integer roleId){
		this.roleId = roleId;
	}

	public Integer getRoleId(){
		return this.roleId;
	}

	public void setMenuId(Integer menuId){
		this.menuId = menuId;
	}

	public Integer getMenuId(){
		return this.menuId;
	}

	public void setCheckType(Integer checkType){
		this.checkType = checkType;
	}

	public Integer getCheckType(){
		return this.checkType;
	}

}
