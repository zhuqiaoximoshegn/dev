package com.easyjob.utils;

import com.easyjob.entity.config.AppConfig;
import com.sun.javafx.scene.traversal.Algorithm;

import javax.annotation.Resource;
import java.util.Base64;
import java.util.Date;

public class JWTUtil {



    @Resource
    private AppConfig appConfig;
    public String createToken(String key, T data, Integer expireDay){
        String token=null;
        try {
            Date expiresAt=new Date(System.currentTimeMillis()+expireDay*24*60*60*1000);
            token=JWT.create()
                    .withClaim(key,JsonUtils.convertObj2Json(data))
                    .withExpiresAt(expiresAt)
                    .sign(Algorithm.HMAC256(appConfig.getJwtCommonSecret()));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return token;
    }

    public <T> T getTokenData(String key,String token,Class<T> classz){
        try {
            if(StringTools.isEmpty(token)){
                return null;
            }
            JWTVerifier verifier=JWT.require(Algorithm.HMAC256(appConfig.getJwtCommonSecret())).build();
            DecoderJWT jwt=verifier.verify(token);
            String jsonData=jwt.getClaim(key).asString();
            return JsonUtils.convertJson2Obj(jsonData,classz);
        } catch (Exception e) {
            return null;
        }
    }

//    public static void main(String[] args) throws Exception{
//        String TOKEN_SECRET="1245";
//        String TOKEN_KEY="key";
//        String token=JWT.create()
//                .withClaim(TOKEN_KEY,"test")
//                .withExpiresAt(new Date(System.currentTimeMillis()+10000))
//                .sign(Algorithm.HMAC256(TOKEN_SECRET));
//        System.out.println(token);
//        JWTVerifier verifier=JWT.require(Algorithm.HMAC256(TOKEN_SECRET)).build();
//        DecoderJWT jwt=verifier.verify(token);
//        String jsonData=jwt.getClaim(TOKEN_KEY).asString();
//        System.out.println(jsonData);
//    }


}
