package com.easyjob.entity.enums;

public enum VerifyRegexEnum {
    NO("", "不校验"),
    EMAIL("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$", "邮箱"),
    PASSWORD("^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$","密码"),
    PHONE("(1[0-9]\\d{9}$)","phone"),
    ACCOUNT("^[]0-9a-zA-z_{1,}$","账户"),
    MONEY("^[0-9]+(.[0-9]{1,2})?$","金额"),
    IP("",""),
    COMMON("",""),
    POSITIVE_INTEGER("","");


    private String regex;
    private String desc;

    VerifyRegexEnum(String regex, String desc) {
        this.regex = regex;
        this.desc = desc;
    }

    public String getRegex() {
        return regex;
    }

    public String getDesc() {
        return desc;
    }
}
