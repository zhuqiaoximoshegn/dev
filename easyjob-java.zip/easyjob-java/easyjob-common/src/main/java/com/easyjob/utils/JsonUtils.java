package com.easyjob.utils;


import com.easyjob.entity.enums.ResponseCodeEnum;
import com.easyjob.exception.BusinessException;

import java.util.List;

public class JsonUtils {
    private static final Logger logger=LoggerFactory.getLogger(JasonUtils.class);

    public static String convertObj2Json(Object obj){return JSON.toJSONString(obj);}

    public static <T> T convertJson2Obj(String json, Class<T> classz){
        try {
            return JSONObject.parseObject(json,classz);
        } catch (Exception e) {
            logger.error("convertJson2Obj异常，json:{}",json);
            throw new BusinessException(ResponseCodeEnum.CODE_601);
        }
    }

    public static<T> List<T> convertJsonArray2List(String json, Class<T> classz){
        try {
            return JSONArray.parseArray(json,classz);
        } catch (Exception e) {
            logger.error("convertJsonArray2List异常，json:{}",json,e);
            throw new BusinessException(ResponseCodeEnum.CODE_601);
        }
    }
}
