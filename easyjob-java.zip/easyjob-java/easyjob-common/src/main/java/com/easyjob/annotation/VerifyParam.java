package com.easyjob.annotation;
import com.easyjob.entity.enums.VerifyRegexEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//parameter verification
@Target({ElementType.PARAMETER,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface VerifyParam {
    VerifyRegexEnum regex() default VerifyRegexEnum.NO;

    int min() default -1;  //min length
    int max() default -1;  //max length

    boolean required() default false;


}
