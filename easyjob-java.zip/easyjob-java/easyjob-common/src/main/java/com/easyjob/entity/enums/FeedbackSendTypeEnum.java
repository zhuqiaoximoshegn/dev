package com.easyjob.entity.enums;

public enum FeedbackSendTypeEnum {
    CLIENT(0,"访客"),ADMIN(1,"管理员");

    private Integer status;
    private String description;

    FeedbackSendTypeEnum(Integer status, String description) {
        this.status = status;
        this.description = description;
    }

    public static FeedbackSendTypeEnum getByStatus(Integer status){
        for(FeedbackSendTypeEnum at: FeedbackSendTypeEnum.values()){
            if(at.status.equals(status)){
                return at;
            }
        }
        return null;
    }

    public Integer getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }


}
