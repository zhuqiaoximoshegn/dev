package com.easyjob.entity.constants;

public class Constants {
    public static final String CHECK_CODE_KEY = "CHECK_CODE_KEY";
    public static final String SESSION_KEY = "session_key";

    public static final Integer LENGTH_8 = 8;
    public static final Integer LENGTH_20 = 20;

    public static final Integer LENGTH_30 = 30;
    public static final Integer LENGTH_50 = 50;
    public static final Integer LENGTH_150 = 150;
    public static final String[] EXCEL_TITLE_QUESTION = new String[]{"标题", "分类名称", "难度", "问题描述", "答案分析"};

    public static final String TABLE_NAME_QUESTION_INFO = "question_info";
    public static final String TABLE_NAME_SHARE_INFO = "share_info";
}
