package com.easyjob.entity.constants;

public class Constants {
    public static final String CHECK_CODE_KEY="CHECK_CODE_KEY";
}
