package com.easyjob.utils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class ScaleFilter {
    private static final Logger logger=LoggerFactory.getLogger(FileController.class);
    public static Boolean createThumbnail(File file, int thumbnailWidth, int thumbnailHeight, File targetFile){
        try{
            BufferedImage src = ImageIO.read(file);

            int sourceW=src.getWidth();
            int sourceH=src.getHeight();

            //小于宽度，不缩
            if(sourceW<=thumbnailWidth){
                return false;
            }
            int height;
            if(sourceW>thumbnailWidth){
                height=thumbnailWidth*sourceH/sourceW;
            }else {
                thumbnailWidth=sourceW;
                height=sourceH;
            }
            BufferedImage dst=new BufferedImage(thumbnailWidth,height,BufferedImage.TYPE_INT_RGB);
            Image scaleImage=src.getScaledInstance(thumbnailWidth,height, Image.SCALE_SMOOTH);
            Graphics2D g=dst.createGraphics();
            g.drawImage(scaleImage,0,0,thumbnailWidth,height,null);
            g.dispose();
            int resultH=dst.getHeight();
            if(resultH>thumbnailHeight){
                resultH=thumbnailHeight;
                dst=dst.getSubimage(0,0,thumbnailWidth,resultH);
            }
            ImageIO.write(dst,"JPEG",targetFile);

        }catch (Exception e){
            logger.error("生成缩略图失败");
        }
        return false;
    }

//    public static void main(String[] args){
//        createThumbnail(new File(""),400,200,new File(""));
//    }
}
