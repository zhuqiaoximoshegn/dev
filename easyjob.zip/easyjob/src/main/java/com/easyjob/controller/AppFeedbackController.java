package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppFeedbackQuery;
import com.easyjob.entity.po.AppFeedback;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppFeedbackService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 问题反馈 Controller
 */
@RestController("appFeedbackController")
@RequestMapping("/appFeedback")
public class AppFeedbackController extends ABaseController{

	@Resource
	private AppFeedbackService appFeedbackService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppFeedbackQuery query){
		return getSuccessResponseVO(appFeedbackService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppFeedback bean) {
		appFeedbackService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppFeedback> listBean) {
		appFeedbackService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppFeedback> listBean) {
		appFeedbackService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据FeedbackId查询对象
	 */
	@RequestMapping("/getAppFeedbackByFeedbackId")
	public ResponseVO getAppFeedbackByFeedbackId(Integer feedbackId) {
		return getSuccessResponseVO(appFeedbackService.getAppFeedbackByFeedbackId(feedbackId));
	}

	/**
	 * 根据FeedbackId修改对象
	 */
	@RequestMapping("/updateAppFeedbackByFeedbackId")
	public ResponseVO updateAppFeedbackByFeedbackId(AppFeedback bean,Integer feedbackId) {
		appFeedbackService.updateAppFeedbackByFeedbackId(bean,feedbackId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据FeedbackId删除
	 */
	@RequestMapping("/deleteAppFeedbackByFeedbackId")
	public ResponseVO deleteAppFeedbackByFeedbackId(Integer feedbackId) {
		appFeedbackService.deleteAppFeedbackByFeedbackId(feedbackId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据FeedbackIdAndUserId查询对象
	 */
	@RequestMapping("/getAppFeedbackByFeedbackIdAndUserId")
	public ResponseVO getAppFeedbackByFeedbackIdAndUserId(Integer feedbackId,String userId) {
		return getSuccessResponseVO(appFeedbackService.getAppFeedbackByFeedbackIdAndUserId(feedbackId,userId));
	}

	/**
	 * 根据FeedbackIdAndUserId修改对象
	 */
	@RequestMapping("/updateAppFeedbackByFeedbackIdAndUserId")
	public ResponseVO updateAppFeedbackByFeedbackIdAndUserId(AppFeedback bean,Integer feedbackId,String userId) {
		appFeedbackService.updateAppFeedbackByFeedbackIdAndUserId(bean,feedbackId,userId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据FeedbackIdAndUserId删除
	 */
	@RequestMapping("/deleteAppFeedbackByFeedbackIdAndUserId")
	public ResponseVO deleteAppFeedbackByFeedbackIdAndUserId(Integer feedbackId,String userId) {
		appFeedbackService.deleteAppFeedbackByFeedbackIdAndUserId(feedbackId,userId);
		return getSuccessResponseVO(null);
	}
}