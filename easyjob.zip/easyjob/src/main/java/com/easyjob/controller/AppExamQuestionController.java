package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppExamQuestionQuery;
import com.easyjob.entity.po.AppExamQuestion;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppExamQuestionService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 考试问题 Controller
 */
@RestController("appExamQuestionController")
@RequestMapping("/appExamQuestion")
public class AppExamQuestionController extends ABaseController{

	@Resource
	private AppExamQuestionService appExamQuestionService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppExamQuestionQuery query){
		return getSuccessResponseVO(appExamQuestionService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppExamQuestion bean) {
		appExamQuestionService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppExamQuestion> listBean) {
		appExamQuestionService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppExamQuestion> listBean) {
		appExamQuestionService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id查询对象
	 */
	@RequestMapping("/getAppExamQuestionById")
	public ResponseVO getAppExamQuestionById(Integer id) {
		return getSuccessResponseVO(appExamQuestionService.getAppExamQuestionById(id));
	}

	/**
	 * 根据Id修改对象
	 */
	@RequestMapping("/updateAppExamQuestionById")
	public ResponseVO updateAppExamQuestionById(AppExamQuestion bean,Integer id) {
		appExamQuestionService.updateAppExamQuestionById(bean,id);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id删除
	 */
	@RequestMapping("/deleteAppExamQuestionById")
	public ResponseVO deleteAppExamQuestionById(Integer id) {
		appExamQuestionService.deleteAppExamQuestionById(id);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据ExamIdAndUserIdAndQuestionId查询对象
	 */
	@RequestMapping("/getAppExamQuestionByExamIdAndUserIdAndQuestionId")
	public ResponseVO getAppExamQuestionByExamIdAndUserIdAndQuestionId(Integer examId,String userId,Integer questionId) {
		return getSuccessResponseVO(appExamQuestionService.getAppExamQuestionByExamIdAndUserIdAndQuestionId(examId,userId,questionId));
	}

	/**
	 * 根据ExamIdAndUserIdAndQuestionId修改对象
	 */
	@RequestMapping("/updateAppExamQuestionByExamIdAndUserIdAndQuestionId")
	public ResponseVO updateAppExamQuestionByExamIdAndUserIdAndQuestionId(AppExamQuestion bean,Integer examId,String userId,Integer questionId) {
		appExamQuestionService.updateAppExamQuestionByExamIdAndUserIdAndQuestionId(bean,examId,userId,questionId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据ExamIdAndUserIdAndQuestionId删除
	 */
	@RequestMapping("/deleteAppExamQuestionByExamIdAndUserIdAndQuestionId")
	public ResponseVO deleteAppExamQuestionByExamIdAndUserIdAndQuestionId(Integer examId,String userId,Integer questionId) {
		appExamQuestionService.deleteAppExamQuestionByExamIdAndUserIdAndQuestionId(examId,userId,questionId);
		return getSuccessResponseVO(null);
	}
}