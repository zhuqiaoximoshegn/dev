package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppExamQuery;
import com.easyjob.entity.po.AppExam;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppExamService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 用户在线考试 Controller
 */
@RestController("appExamController")
@RequestMapping("/appExam")
public class AppExamController extends ABaseController{

	@Resource
	private AppExamService appExamService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppExamQuery query){
		return getSuccessResponseVO(appExamService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppExam bean) {
		appExamService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppExam> listBean) {
		appExamService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppExam> listBean) {
		appExamService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据ExamId查询对象
	 */
	@RequestMapping("/getAppExamByExamId")
	public ResponseVO getAppExamByExamId(Integer examId) {
		return getSuccessResponseVO(appExamService.getAppExamByExamId(examId));
	}

	/**
	 * 根据ExamId修改对象
	 */
	@RequestMapping("/updateAppExamByExamId")
	public ResponseVO updateAppExamByExamId(AppExam bean,Integer examId) {
		appExamService.updateAppExamByExamId(bean,examId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据ExamId删除
	 */
	@RequestMapping("/deleteAppExamByExamId")
	public ResponseVO deleteAppExamByExamId(Integer examId) {
		appExamService.deleteAppExamByExamId(examId);
		return getSuccessResponseVO(null);
	}
}