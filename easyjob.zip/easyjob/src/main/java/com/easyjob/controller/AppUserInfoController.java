package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppUserInfoQuery;
import com.easyjob.entity.po.AppUserInfo;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppUserInfoService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 *  Controller
 */
@RestController("appUserInfoController")
@RequestMapping("/appUserInfo")
public class AppUserInfoController extends ABaseController{

	@Resource
	private AppUserInfoService appUserInfoService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppUserInfoQuery query){
		return getSuccessResponseVO(appUserInfoService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppUserInfo bean) {
		appUserInfoService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppUserInfo> listBean) {
		appUserInfoService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppUserInfo> listBean) {
		appUserInfoService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据UserId查询对象
	 */
	@RequestMapping("/getAppUserInfoByUserId")
	public ResponseVO getAppUserInfoByUserId(String userId) {
		return getSuccessResponseVO(appUserInfoService.getAppUserInfoByUserId(userId));
	}

	/**
	 * 根据UserId修改对象
	 */
	@RequestMapping("/updateAppUserInfoByUserId")
	public ResponseVO updateAppUserInfoByUserId(AppUserInfo bean,String userId) {
		appUserInfoService.updateAppUserInfoByUserId(bean,userId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据UserId删除
	 */
	@RequestMapping("/deleteAppUserInfoByUserId")
	public ResponseVO deleteAppUserInfoByUserId(String userId) {
		appUserInfoService.deleteAppUserInfoByUserId(userId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Email查询对象
	 */
	@RequestMapping("/getAppUserInfoByEmail")
	public ResponseVO getAppUserInfoByEmail(String email) {
		return getSuccessResponseVO(appUserInfoService.getAppUserInfoByEmail(email));
	}

	/**
	 * 根据Email修改对象
	 */
	@RequestMapping("/updateAppUserInfoByEmail")
	public ResponseVO updateAppUserInfoByEmail(AppUserInfo bean,String email) {
		appUserInfoService.updateAppUserInfoByEmail(bean,email);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Email删除
	 */
	@RequestMapping("/deleteAppUserInfoByEmail")
	public ResponseVO deleteAppUserInfoByEmail(String email) {
		appUserInfoService.deleteAppUserInfoByEmail(email);
		return getSuccessResponseVO(null);
	}
}