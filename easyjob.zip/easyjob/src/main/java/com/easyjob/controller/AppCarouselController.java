package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppCarouselQuery;
import com.easyjob.entity.po.AppCarousel;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppCarouselService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * app轮播 Controller
 */
@RestController("appCarouselController")
@RequestMapping("/appCarousel")
public class AppCarouselController extends ABaseController{

	@Resource
	private AppCarouselService appCarouselService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppCarouselQuery query){
		return getSuccessResponseVO(appCarouselService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppCarousel bean) {
		appCarouselService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppCarousel> listBean) {
		appCarouselService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppCarousel> listBean) {
		appCarouselService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据CarouselId查询对象
	 */
	@RequestMapping("/getAppCarouselByCarouselId")
	public ResponseVO getAppCarouselByCarouselId(Integer carouselId) {
		return getSuccessResponseVO(appCarouselService.getAppCarouselByCarouselId(carouselId));
	}

	/**
	 * 根据CarouselId修改对象
	 */
	@RequestMapping("/updateAppCarouselByCarouselId")
	public ResponseVO updateAppCarouselByCarouselId(AppCarousel bean,Integer carouselId) {
		appCarouselService.updateAppCarouselByCarouselId(bean,carouselId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据CarouselId删除
	 */
	@RequestMapping("/deleteAppCarouselByCarouselId")
	public ResponseVO deleteAppCarouselByCarouselId(Integer carouselId) {
		appCarouselService.deleteAppCarouselByCarouselId(carouselId);
		return getSuccessResponseVO(null);
	}
}