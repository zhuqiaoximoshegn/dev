package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppUpdateQuery;
import com.easyjob.entity.po.AppUpdate;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppUpdateService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * app发布 Controller
 */
@RestController("appUpdateController")
@RequestMapping("/appUpdate")
public class AppUpdateController extends ABaseController{

	@Resource
	private AppUpdateService appUpdateService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppUpdateQuery query){
		return getSuccessResponseVO(appUpdateService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppUpdate bean) {
		appUpdateService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppUpdate> listBean) {
		appUpdateService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppUpdate> listBean) {
		appUpdateService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id查询对象
	 */
	@RequestMapping("/getAppUpdateById")
	public ResponseVO getAppUpdateById(Integer id) {
		return getSuccessResponseVO(appUpdateService.getAppUpdateById(id));
	}

	/**
	 * 根据Id修改对象
	 */
	@RequestMapping("/updateAppUpdateById")
	public ResponseVO updateAppUpdateById(AppUpdate bean,Integer id) {
		appUpdateService.updateAppUpdateById(bean,id);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id删除
	 */
	@RequestMapping("/deleteAppUpdateById")
	public ResponseVO deleteAppUpdateById(Integer id) {
		appUpdateService.deleteAppUpdateById(id);
		return getSuccessResponseVO(null);
	}
}