package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.ExamQuestionItemQuery;
import com.easyjob.entity.po.ExamQuestionItem;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.ExamQuestionItemService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 *  Controller
 */
@RestController("examQuestionItemController")
@RequestMapping("/examQuestionItem")
public class ExamQuestionItemController extends ABaseController{

	@Resource
	private ExamQuestionItemService examQuestionItemService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(ExamQuestionItemQuery query){
		return getSuccessResponseVO(examQuestionItemService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(ExamQuestionItem bean) {
		examQuestionItemService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<ExamQuestionItem> listBean) {
		examQuestionItemService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<ExamQuestionItem> listBean) {
		examQuestionItemService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据ItemId查询对象
	 */
	@RequestMapping("/getExamQuestionItemByItemId")
	public ResponseVO getExamQuestionItemByItemId(Integer itemId) {
		return getSuccessResponseVO(examQuestionItemService.getExamQuestionItemByItemId(itemId));
	}

	/**
	 * 根据ItemId修改对象
	 */
	@RequestMapping("/updateExamQuestionItemByItemId")
	public ResponseVO updateExamQuestionItemByItemId(ExamQuestionItem bean,Integer itemId) {
		examQuestionItemService.updateExamQuestionItemByItemId(bean,itemId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据ItemId删除
	 */
	@RequestMapping("/deleteExamQuestionItemByItemId")
	public ResponseVO deleteExamQuestionItemByItemId(Integer itemId) {
		examQuestionItemService.deleteExamQuestionItemByItemId(itemId);
		return getSuccessResponseVO(null);
	}
}