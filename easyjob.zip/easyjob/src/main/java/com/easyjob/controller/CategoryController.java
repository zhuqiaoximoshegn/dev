package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.CategoryQuery;
import com.easyjob.entity.po.Category;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.CategoryService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 分类 Controller
 */
@RestController("categoryController")
@RequestMapping("/category")
public class CategoryController extends ABaseController{

	@Resource
	private CategoryService categoryService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(CategoryQuery query){
		return getSuccessResponseVO(categoryService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(Category bean) {
		categoryService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<Category> listBean) {
		categoryService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<Category> listBean) {
		categoryService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据CategoryId查询对象
	 */
	@RequestMapping("/getCategoryByCategoryId")
	public ResponseVO getCategoryByCategoryId(Integer categoryId) {
		return getSuccessResponseVO(categoryService.getCategoryByCategoryId(categoryId));
	}

	/**
	 * 根据CategoryId修改对象
	 */
	@RequestMapping("/updateCategoryByCategoryId")
	public ResponseVO updateCategoryByCategoryId(Category bean,Integer categoryId) {
		categoryService.updateCategoryByCategoryId(bean,categoryId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据CategoryId删除
	 */
	@RequestMapping("/deleteCategoryByCategoryId")
	public ResponseVO deleteCategoryByCategoryId(Integer categoryId) {
		categoryService.deleteCategoryByCategoryId(categoryId);
		return getSuccessResponseVO(null);
	}
}