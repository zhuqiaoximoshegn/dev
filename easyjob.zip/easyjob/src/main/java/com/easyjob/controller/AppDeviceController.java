package com.easyjob.controller;

import java.util.List;

import com.easyjob.entity.query.AppDeviceQuery;
import com.easyjob.entity.po.AppDevice;
import com.easyjob.entity.vo.ResponseVO;
import com.easyjob.service.AppDeviceService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 设备信息 Controller
 */
@RestController("appDeviceController")
@RequestMapping("/appDevice")
public class AppDeviceController extends ABaseController{

	@Resource
	private AppDeviceService appDeviceService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(AppDeviceQuery query){
		return getSuccessResponseVO(appDeviceService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(AppDevice bean) {
		appDeviceService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<AppDevice> listBean) {
		appDeviceService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<AppDevice> listBean) {
		appDeviceService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据DeviceId查询对象
	 */
	@RequestMapping("/getAppDeviceByDeviceId")
	public ResponseVO getAppDeviceByDeviceId(String deviceId) {
		return getSuccessResponseVO(appDeviceService.getAppDeviceByDeviceId(deviceId));
	}

	/**
	 * 根据DeviceId修改对象
	 */
	@RequestMapping("/updateAppDeviceByDeviceId")
	public ResponseVO updateAppDeviceByDeviceId(AppDevice bean,String deviceId) {
		appDeviceService.updateAppDeviceByDeviceId(bean,deviceId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据DeviceId删除
	 */
	@RequestMapping("/deleteAppDeviceByDeviceId")
	public ResponseVO deleteAppDeviceByDeviceId(String deviceId) {
		appDeviceService.deleteAppDeviceByDeviceId(deviceId);
		return getSuccessResponseVO(null);
	}
}