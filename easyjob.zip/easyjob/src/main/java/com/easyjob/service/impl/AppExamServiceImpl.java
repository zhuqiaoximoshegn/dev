package com.easyjob.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.easyjob.entity.enums.PageSize;
import com.easyjob.entity.query.AppExamQuery;
import com.easyjob.entity.po.AppExam;
import com.easyjob.entity.vo.PaginationResultVO;
import com.easyjob.entity.query.SimplePage;
import com.easyjob.mappers.AppExamMapper;
import com.easyjob.service.AppExamService;
import com.easyjob.utils.StringTools;


/**
 * 用户在线考试 业务接口实现
 */
@Service("appExamService")
public class AppExamServiceImpl implements AppExamService {

	@Resource
	private AppExamMapper<AppExam, AppExamQuery> appExamMapper;

	/**
	 * 根据条件查询列表
	 */
	@Override
	public List<AppExam> findListByParam(AppExamQuery param) {
		return this.appExamMapper.selectList(param);
	}

	/**
	 * 根据条件查询列表
	 */
	@Override
	public Integer findCountByParam(AppExamQuery param) {
		return this.appExamMapper.selectCount(param);
	}

	/**
	 * 分页查询方法
	 */
	@Override
	public PaginationResultVO<AppExam> findListByPage(AppExamQuery param) {
		int count = this.findCountByParam(param);
		int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

		SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
		param.setSimplePage(page);
		List<AppExam> list = this.findListByParam(param);
		PaginationResultVO<AppExam> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
		return result;
	}

	/**
	 * 新增
	 */
	@Override
	public Integer add(AppExam bean) {
		return this.appExamMapper.insert(bean);
	}

	/**
	 * 批量新增
	 */
	@Override
	public Integer addBatch(List<AppExam> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.appExamMapper.insertBatch(listBean);
	}

	/**
	 * 批量新增或者修改
	 */
	@Override
	public Integer addOrUpdateBatch(List<AppExam> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.appExamMapper.insertOrUpdateBatch(listBean);
	}

	/**
	 * 多条件更新
	 */
	@Override
	public Integer updateByParam(AppExam bean, AppExamQuery param) {
		StringTools.checkParam(param);
		return this.appExamMapper.updateByParam(bean, param);
	}

	/**
	 * 多条件删除
	 */
	@Override
	public Integer deleteByParam(AppExamQuery param) {
		StringTools.checkParam(param);
		return this.appExamMapper.deleteByParam(param);
	}

	/**
	 * 根据ExamId获取对象
	 */
	@Override
	public AppExam getAppExamByExamId(Integer examId) {
		return this.appExamMapper.selectByExamId(examId);
	}

	/**
	 * 根据ExamId修改
	 */
	@Override
	public Integer updateAppExamByExamId(AppExam bean, Integer examId) {
		return this.appExamMapper.updateByExamId(bean, examId);
	}

	/**
	 * 根据ExamId删除
	 */
	@Override
	public Integer deleteAppExamByExamId(Integer examId) {
		return this.appExamMapper.deleteByExamId(examId);
	}
}